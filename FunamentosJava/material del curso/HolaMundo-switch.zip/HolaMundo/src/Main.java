import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        var numero = 1;
        var texto = "numero desconocido";
        switch (numero){
            case 1:
                texto = "numero uno";
                break;
            case 2:
                texto = "numero dos";
                break;
            case 3:
                texto = "numero tres";
                break;
            default:
                texto = "numero desconocido";
                break;
        }
        System.out.println("texto = " + texto);
    }
}
