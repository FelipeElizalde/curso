import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
      int a = 10;
      int valorMinimo = 0, valorMaximo = 10;
      if(a >= valorMinimo && a <= valorMaximo)
          System.out.println("dentro de rango");
      else
          System.out.println("fuera de rango");

      boolean vacaciones = true;
      boolean diaDescanso = false;
      if(vacaciones || diaDescanso)
          System.out.println("Padre puede asistir al juego del hijo");
      else
          System.out.println("Padre ocupado");
    }
}
