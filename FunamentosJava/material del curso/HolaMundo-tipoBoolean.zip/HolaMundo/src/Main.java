import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
       //boolean
        //System.out.println("bits tipo boolean:" + Boolean.SIZE);
        //System.out.println("bytes tipo boolean:" + Boolean.BYTES);
        System.out.println("true tipo boolean:" + Boolean.TRUE);
        System.out.println("false maximo tipo boolean:" + Boolean.FALSE);

        boolean booleanVar = true;

        if(booleanVar)
            System.out.println("La variable contiene un valor verdadero");
        else
            System.out.println("La variable contiene un valor falso");

        System.out.println();
        var edad = 23;
        var adulto = edad >= 18;
        if(adulto)
            System.out.println("Eres mayor de edad, puedes pasar");
        else
            System.out.println("Eres menor de edad, no puedes pasar");
    }
}
