import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        var i = 0;
        /*
        while(i < 3){
            System.out.println("i = " + i);
            i++;
        }
        */
        do{
            System.out.println("i = " + i);
            i++;
        } while(i < 3);
    }
}
