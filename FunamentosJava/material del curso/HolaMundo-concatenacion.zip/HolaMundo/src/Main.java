public class Main {
    public static void main(String[] args) {
        var usuario = "Juan";
        var saludar = "Hola";
        System.out.println(saludar + " " + usuario);

        //Saludos, mi nombre es Juan
        System.out.println("Saludos, mi nombre es" + " " + usuario);

        System.out.println("saludar = " + saludar);
    }
}
