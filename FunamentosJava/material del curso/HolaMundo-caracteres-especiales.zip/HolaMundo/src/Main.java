public class Main {
    public static void main(String[] args) {
        String nombre = "Karla";
        String apellido = "Esparza";

        System.out.println(nombre + " " + apellido);
        System.out.println("Nueva linea: \n" + nombre);
        System.out.println("Tabulador: \t" + nombre);
        System.out.println("Retroceso: \b" + nombre);
        System.out.println("Retorno de carro: \r" + nombre);
        System.out.println("Comilla simple: \'" + nombre + "\'");
        System.out.println("Commilla doble \"" + nombre + "\"");
        System.out.println();
        System.out.print("nombre");

    }
}
