import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //char
        System.out.println("bits tipo char:" + Character.SIZE);
        System.out.println("bytes tipo char:" + Character.BYTES);
        System.out.println("valor minimo tipo char:" + Character.MIN_VALUE);
        System.out.println("valor maximo tipo char:" + Character.MAX_VALUE);

        var c = '\u0021';
        //var c = 33;
        //var c = '!';
        System.out.println("c = " + c);


    }
}
