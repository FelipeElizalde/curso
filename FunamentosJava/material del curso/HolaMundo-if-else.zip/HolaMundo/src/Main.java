import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        var numero = 2;
        var texto = "numero desconocido";

        if(numero == 1)
            texto = "numero uno";
        else if(numero == 2)
            texto = "numero dos";
        else if(numero == 3)
            texto = "numero tres";
        else
            texto = "numero desconocido";

        System.out.println("texto = " + texto);
        
    }
}
