import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //decimal
        var b1 = 10;
        System.out.println("b1 = " + b1);
        //hexadecimal
        var b2 = 0xa;
        System.out.println("b2 = " + b2);
        //octal
        var b3 = 012;
        System.out.println("b3 = " + b3);
    }
}
